// changed_screen_parts.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "videodriver.h"
void handle_driver_input(PCHANGES_BUF pchanges_buf, int i);

int _tmain(int argc, _TCHAR* argv[])
{
	VIDEODRIVER mydriver;
	// if depth==0, we take the current depth
	HDC hDisplayDC_Temp;
	hDisplayDC_Temp= CreateDC("DISPLAY",NULL,NULL,NULL);
	int cxWidth= GetDeviceCaps(hDisplayDC_Temp,HORZRES) ;
	int cyHeight = GetDeviceCaps(hDisplayDC_Temp,VERTRES);
	DeleteDC(hDisplayDC_Temp);
	mydriver.VIDEODRIVER_start(0,0,cxWidth,cyHeight,0);
	if (!mydriver.mypVideoMemory) return 0; //error
	PCHANGES_BUF pchanges_buf;
	pchanges_buf=mydriver.mypchangebuf;
	int oldaantal=0;
	int counter=pchanges_buf->counter;
	int runs=0;
	while(runs<10)
	{
		runs++;
		counter=pchanges_buf->counter;
		if (oldaantal!=counter && (counter>=1 || counter <=1999))
		{
				oldaantal=counter;
				if (oldaantal<counter)
				{
					for (int i =oldaantal+1; i<=counter;i++)
						{
							handle_driver_input(pchanges_buf,i);
						}

				}
				else
				{
					int i = 0;
					for (i =oldaantal+1;i<MAXCHANGES_BUF;i++)
						{
							handle_driver_input(pchanges_buf,i);
						}
					for (i=1;i<=counter;i++)
						{
							handle_driver_input(pchanges_buf,i);
						}
		}	
		}		
	}
	Sleep(5000);
	return 0;
}


void handle_driver_input(PCHANGES_BUF pchanges_buf, int i)
{
	switch(pchanges_buf->pointrect[i].type)
			{
				case SCREEN_SCREEN:
					{
						int dx=pchanges_buf->pointrect[i].point.x;
						int dy=pchanges_buf->pointrect[i].point.y;
						int left=pchanges_buf->pointrect[i].rect.left;
						int right=pchanges_buf->pointrect[i].rect.right;
						int top=pchanges_buf->pointrect[i].rect.top;
						int bottom=pchanges_buf->pointrect[i].rect.bottom;
						printf("move dx=%i dy=%i rect=%i right=%i top=%i bottom=%i \n",dx,dy,left,right,top,bottom);
						break;
					}

				case SOLIDFILL:
				case TEXTOUT:
				case BLEND:
				case TRANS:
				case PLG:
				case BLIT:
					{
					int left=pchanges_buf->pointrect[i].rect.left;
					int right=pchanges_buf->pointrect[i].rect.right;
					int top=pchanges_buf->pointrect[i].rect.top;
					int bottom=pchanges_buf->pointrect[i].rect.bottom;
					printf("blit rect=%i right=%i top=%i bottom=%i \n",left,right,top,bottom);
					}

					break;
				default:
					break;
			}
}

