// screentoavi.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "screentoavi.h"
#include "avigenerator.h"
#include "videodriver.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								
CAVIGenerator *AviGen;
int cxWidth;
int cyHeight;
int screenwidth;
int screenheight;

HDC hDisplayDC;
HDC hDibDC;
char * pDibBits;
BITMAPINFO BitmapInfo;
void stop();
void start();
void update();
VIDEODRIVER *m_videodriver;
char *tempbuffer;

INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	AviGen=NULL;
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, About);
}



// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_TIMER:
		update();
		break;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_BUTTON3 || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}

		if (LOWORD(wParam) == IDC_BUTTON1)
		{
			//start
			start();
			SetTimer(hDlg, 1, 50, NULL);
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_BUTTON2)
		{
			//stop
			KillTimer(hDlg, 1);
			stop();
			return (INT_PTR)TRUE;
		}
	}
	return (INT_PTR)FALSE;
}

void
bitmapinfo()
{
	pDibBits=NULL;
	hDisplayDC = CreateDC("DISPLAY",NULL,NULL,NULL);
	cxWidth= GetDeviceCaps(hDisplayDC,HORZRES) ;
	cyHeight = GetDeviceCaps(hDisplayDC,VERTRES);
	screenwidth=cxWidth;
	screenheight=cyHeight;
	if (cxWidth>1280) cxWidth=1280;
	if (cyHeight>720) cyHeight=720;
	hDibDC = CreateCompatibleDC(hDisplayDC);
	memset(&BitmapInfo, 0, sizeof(BITMAPINFO));
	BitmapInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	BitmapInfo.bmiHeader.biWidth = cxWidth;
	BitmapInfo.bmiHeader.biHeight = -cyHeight;
	BitmapInfo.bmiHeader.biPlanes = 1;
	BitmapInfo.bmiHeader.biBitCount = 32;
	BitmapInfo.bmiHeader.biCompression = BI_RGB;
	BitmapInfo.bmiHeader.biSizeImage=cyHeight*cxWidth*4;
}

void
start()
{
	bitmapinfo();
	m_videodriver=new VIDEODRIVER;
	tempbuffer= new char[cyHeight*cxWidth*4];
	m_videodriver->VIDEODRIVER_start(0,0,GetDeviceCaps(hDisplayDC,HORZRES),GetDeviceCaps(hDisplayDC,VERTRES),32);
	if (!m_videodriver->mypVideoMemory)
	{
		//error, the shared memory ( memory mapped file) is not found
		return;
	}
	// We force a full screen redraw to init the MD
	else InvalidateRect(NULL,NULL,TRUE);
	//tell the MD to show the cursor
	m_videodriver->HardwareCursor();

	SYSTEMTIME lt;    
	GetLocalTime(&lt);
	char str[MAX_PATH + 32]; // 29 January 2008 jdp 
	_snprintf(str, sizeof str, "%02d_%02d_%02d_%02d_%02d", lt.wMonth,lt.wDay,lt.wHour, lt.wMinute,lt.wSecond);
	strcat(str,"_vnc.avi");
	AviGen = new CAVIGenerator(str,"c:\\temp",&BitmapInfo.bmiHeader,5);
	HRESULT hr;
	hr=AviGen->InitEngine();
	if (FAILED(hr))
	{
		AviGen->ReleaseEngine(); 
		delete AviGen;
		AviGen=NULL;
	}
	//  The MD always need to cover the full screen
	//  If the MD cover only a part of the screen, moving a window out/in the selected part cause screen corruption
	
}

void
stop()
{
	if (AviGen)
		{
			AviGen->ReleaseEngine(); 
			delete AviGen;
			AviGen=NULL;
		}

	if (hDisplayDC != NULL)
	{
		if (!DeleteDC(hDisplayDC))
		hDisplayDC = NULL;
	}
	if (hDibDC  != NULL)
	{
		// Release our device context
		if (!DeleteDC(hDibDC ))
		{
		}
		hDibDC  = NULL;
	}

	if (m_videodriver)
		delete m_videodriver;
	m_videodriver=NULL;
	delete []tempbuffer;
}

void
update()
{
	if (m_videodriver!=NULL)
		if (m_videodriver->mypVideoMemory!=NULL)
		{
			// The MD is of the format screenwidth*screenheight
			// Avi is restricted to HD (codec limitation
			// see
			// if (cxWidth>1280) cxWidth=1280;
			// if (cyHeight>720) cyHeight=720;
			if (screenwidth==cxWidth && screenheight==cyHeight) /// buffer are the same, just use them
				AviGen->AddFrame((BYTE*)m_videodriver->myframebuffer);
			else
			{
				int OutputWidth=cxWidth;
				int OutputHeight=cyHeight;
				int bytesPerInputRow = screenwidth * 4;
				int bytesPerOutputRow = cxWidth * 4;

				char *sourcepos= m_videodriver->myframebuffer;
				char *destpos=tempbuffer;
				int height=OutputHeight;
				char *iptr=sourcepos;
				char *optr=destpos;
				while (height > 0) {
				memcpy(optr, iptr, bytesPerOutputRow);
				iptr += bytesPerInputRow;
				optr += bytesPerOutputRow;
				height--;
					}
				AviGen->AddFrame((BYTE*)tempbuffer);
			}
			
		}

}


