// screentoavi.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "screentoavi.h"
#include "avigenerator.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								
CAVIGenerator *AviGen;
int cxWidth;
int cyHeight;

HDC hDisplayDC;
HDC hDibDC;
HBITMAP hDib;
char * pDibBits;
BITMAPINFO BitmapInfo;
void stop();
void start();
void update();

INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	AviGen=NULL;
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, About);
}



// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_TIMER:
		update();
		break;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_BUTTON3 || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}

		if (LOWORD(wParam) == IDC_BUTTON1)
		{
			//start
			start();
			SetTimer(hDlg, 1, 33, NULL);
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_BUTTON2)
		{
			//stop
			KillTimer(hDlg, 1);
			stop();
			return (INT_PTR)TRUE;
		}
	}
	return (INT_PTR)FALSE;
}

void
bitmapinfo()
{
	pDibBits=NULL;
	hDisplayDC = CreateDC("DISPLAY",NULL,NULL,NULL);
	cxWidth= GetDeviceCaps(hDisplayDC,HORZRES) ;
	cyHeight = GetDeviceCaps(hDisplayDC,VERTRES);
	if (cxWidth>1280) cxWidth=1280;
	if (cyHeight>720) cyHeight=720;
	hDibDC = CreateCompatibleDC(hDisplayDC);
	memset(&BitmapInfo, 0, sizeof(BITMAPINFO));
	BitmapInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	BitmapInfo.bmiHeader.biWidth = cxWidth;
	BitmapInfo.bmiHeader.biHeight = -cyHeight;
	BitmapInfo.bmiHeader.biPlanes = 1;
	BitmapInfo.bmiHeader.biBitCount = 32;
	BitmapInfo.bmiHeader.biCompression = BI_RGB;
	BitmapInfo.bmiHeader.biSizeImage=cyHeight*cxWidth*4;
	hDib = CreateDIBSection(hDisplayDC,&BitmapInfo,DIB_RGB_COLORS,(void**)&pDibBits,NULL,0);
}

void
start()
{
	bitmapinfo();
	SYSTEMTIME lt;    
	GetLocalTime(&lt);
	char str[MAX_PATH + 32]; // 29 January 2008 jdp 
	_snprintf(str, sizeof str, "%02d_%02d_%02d_%02d_%02d", lt.wMonth,lt.wDay,lt.wHour, lt.wMinute,lt.wSecond);
	strcat(str,"_vnc.avi");
	AviGen = new CAVIGenerator(str,"c:\\temp",&BitmapInfo.bmiHeader,5);
	HRESULT hr;
	hr=AviGen->InitEngine();
	if (FAILED(hr))
	{
		AviGen->ReleaseEngine(); 
		delete AviGen;
		AviGen=NULL;
	}
}

void
stop()
{
	if (AviGen)
		{
			AviGen->ReleaseEngine(); 
			delete AviGen;
			AviGen=NULL;
		}

	if (hDisplayDC != NULL)
	{
		if (!DeleteDC(hDisplayDC))
		hDisplayDC = NULL;
	}
	if (hDibDC  != NULL)
	{
		// Release our device context
		if (!DeleteDC(hDibDC ))
		{
		}
		hDibDC  = NULL;
	}
	if (hDib != NULL)
	{
		// Release the custom bitmap, if any
		if (!DeleteObject(hDib))
		{
		}
		hDib = NULL;
	}
}

void
update()
{
	HBITMAP hTemp = (HBITMAP)SelectObject(hDibDC,hDib);
	BitBlt(hDibDC,0,0,cxWidth,cyHeight,hDisplayDC,0,0,CAPTUREBLT |SRCCOPY);
	SelectObject(hDibDC, hTemp);
	AviGen->AddFrame((BYTE*)pDibBits);
}


