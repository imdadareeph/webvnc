char buildtime[] = __DATE__ " " __TIME__;
